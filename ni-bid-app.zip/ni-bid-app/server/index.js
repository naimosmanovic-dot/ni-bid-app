'use strict';
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const multer  = require('multer');
const bcrypt  = require('bcryptjs');
const path    = require('path');
const fs      = require('fs');
const fetch   = require('node-fetch');
const { v4: uuid } = require('uuid');
const XLSX    = require('xlsx');
const Database = require('better-sqlite3');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── DATABASE ──────────────────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, '../data/ni.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'estimator',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    address TEXT NOT NULL,
    architect TEXT,
    pm TEXT,
    bid_number TEXT,
    date TEXT,
    status TEXT DEFAULT 'draft',
    pct_gc REAL DEFAULT 8,
    pct_oh REAL DEFAULT 10,
    pct_ins REAL DEFAULT 8,
    scope_notes TEXT,
    divisions JSON,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// ── SEED DEFAULT USERS ────────────────────────────────────────────────────────
const seedUser = (username, password, role = 'estimator') => {
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (!exists) {
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('INSERT INTO users (id, username, password_hash, role) VALUES (?, ?, ?, ?)')
      .run(uuid(), username, hash, role);
    console.log(`✓ Created user: ${username}`);
  }
};

seedUser('naim', process.env.ADMIN_PASSWORD || 'ni2026secure', 'admin');
// Add more team members here:
// seedUser('estimator1', 'password123', 'estimator');

// ── MIDDLEWARE ────────────────────────────────────────────────────────────────
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'ni-construction-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  }
}));

// File uploads (kept in memory for API forwarding)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 20 }
});

// Auth middleware
const requireAuth = (req, res, next) => {
  if (req.session?.userId) return next();
  res.status(401).json({ error: 'Not authenticated' });
};

// ── STATIC ────────────────────────────────────────────────────────────────────
const CLIENT_DIR = path.join(__dirname, '../client/public');
app.use(express.static(CLIENT_DIR));

// ── AUTH ROUTES ───────────────────────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  req.session.userId   = user.id;
  req.session.username = user.username;
  req.session.role     = user.role;
  res.json({ ok: true, username: user.username, role: user.role });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json({ username: req.session.username, role: req.session.role });
});

// ── PROJECT ROUTES ────────────────────────────────────────────────────────────
// List all projects for this user
app.get('/api/projects', requireAuth, (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC'
  ).all(req.session.userId);

  const projects = rows.map(r => ({
    ...r,
    divisions: JSON.parse(r.divisions || '[]')
  }));
  res.json(projects);
});

// Get single project
app.get('/api/projects/:id', requireAuth, (req, res) => {
  const row = db.prepare(
    'SELECT * FROM projects WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.session.userId);
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.json({ ...row, divisions: JSON.parse(row.divisions || '[]') });
});

// Create project
app.post('/api/projects', requireAuth, (req, res) => {
  const id = uuid();
  const { address, architect, pm, bid_number, date, status,
          pct_gc, pct_oh, pct_ins, scope_notes, divisions } = req.body;
  db.prepare(`INSERT INTO projects 
    (id, user_id, address, architect, pm, bid_number, date, status,
     pct_gc, pct_oh, pct_ins, scope_notes, divisions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, req.session.userId, address, architect, pm, bid_number, date,
         status || 'draft', pct_gc || 8, pct_oh || 10, pct_ins || 8,
         scope_notes, JSON.stringify(divisions || []));
  const row = db.prepare('SELECT * FROM projects WHERE id = ?').get(id);
  res.json({ ...row, divisions: JSON.parse(row.divisions) });
});

// Update project
app.put('/api/projects/:id', requireAuth, (req, res) => {
  const { address, architect, pm, bid_number, date, status,
          pct_gc, pct_oh, pct_ins, scope_notes, divisions } = req.body;
  db.prepare(`UPDATE projects SET
    address=?, architect=?, pm=?, bid_number=?, date=?, status=?,
    pct_gc=?, pct_oh=?, pct_ins=?, scope_notes=?, divisions=?,
    updated_at=datetime('now')
    WHERE id=? AND user_id=?`)
    .run(address, architect, pm, bid_number, date, status,
         pct_gc, pct_oh, pct_ins, scope_notes,
         JSON.stringify(divisions || []),
         req.params.id, req.session.userId);
  const row = db.prepare('SELECT * FROM projects WHERE id=?').get(req.params.id);
  res.json({ ...row, divisions: JSON.parse(row.divisions || '[]') });
});

// Delete project
app.delete('/api/projects/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM projects WHERE id=? AND user_id=?')
    .run(req.params.id, req.session.userId);
  res.json({ ok: true });
});

// ── AI ANALYSIS ROUTE ─────────────────────────────────────────────────────────
app.post('/api/analyze', requireAuth, upload.array('drawings', 20), async (req, res) => {
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY not configured' });
  }
  if (!req.files || !req.files.length) {
    return res.status(400).json({ error: 'No files uploaded' });
  }

  try {
    const content = [];

    // Add each drawing file
    for (const file of req.files) {
      const b64 = file.buffer.toString('base64');
      const mt  = file.mimetype;
      if (mt === 'application/pdf') {
        content.push({ type:'document', source:{ type:'base64', media_type:'application/pdf', data:b64 }});
      } else if (mt.startsWith('image/')) {
        content.push({ type:'image', source:{ type:'base64', media_type:mt, data:b64 }});
      }
    }

    content.push({ type:'text', text: ANALYSIS_PROMPT });

    const apiRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 4000,
        messages: [{ role:'user', content }]
      })
    });

    if (!apiRes.ok) {
      const err = await apiRes.text();
      throw new Error('Anthropic API error: ' + err);
    }

    const data = await apiRes.json();
    const rawText = data.content.map(b => b.text || '').join('');

    // Extract JSON from response
    const jsonMatch = rawText.match(/```json\s*([\s\S]*?)\s*```/) ||
                      rawText.match(/(\{[\s\S]*\})/);
    if (!jsonMatch) throw new Error('Could not parse AI response');

    const bidData = JSON.parse(jsonMatch[1]);
    res.json({ ok: true, bidData, rawText });

  } catch (err) {
    console.error('AI analysis error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── EXCEL EXPORT ROUTE ────────────────────────────────────────────────────────
app.post('/api/export/excel', requireAuth, (req, res) => {
  const p = req.body;
  const sub = p.divisions.reduce((s,d)=>s+d.items.reduce((ss,it)=>ss+(parseFloat(it.cost)||0),0),0);
  const gc  = Math.round(sub * p.pct_gc  / 100);
  const oh  = Math.round(sub * p.pct_oh  / 100);
  const ins = Math.round(sub * p.pct_ins / 100);
  const grand = sub + gc + oh + ins;
  const fmt = n => n ? '$' + Math.round(n).toLocaleString('en-US') : '';

  const wb = XLSX.utils.book_new();

  // ── PROPOSAL SHEET ──
  const rows = [];
  rows.push(['NI CONSTRUCTION CORP.']);
  rows.push(['License #2056165-DCA · 244 5th Ave Suite 2NB, New York NY 10001']);
  rows.push([]);
  rows.push(['PROPOSAL']);
  rows.push([]);
  rows.push(['PROJECT:', p.address]);
  rows.push(['ARCHITECT:', p.architect]);
  rows.push(['PROJECT MANAGER:', p.pm]);
  rows.push(['BID NUMBER:', p.bid_number]);
  rows.push(['DATE:', p.date]);
  rows.push([]);
  rows.push(['DIV','LINE ITEM','REMARK','COST']);

  p.divisions.forEach(div => {
    const dt = div.items.reduce((s,it)=>s+(parseFloat(it.cost)||0),0);
    rows.push([`DIV ${div.div}`, div.name.toUpperCase(), '', fmt(dt)]);
    div.items.forEach(it => rows.push(['', '  '+it.name, it.remark||'', it.cost ? fmt(it.cost) : '']));
    rows.push([]);
  });

  rows.push(['','DIRECT COST SUBTOTAL','', fmt(sub)]);
  rows.push(['',`General Conditions (${p.pct_gc}%)`, '', fmt(gc)]);
  rows.push(['',`Overhead & Profit (${p.pct_oh}%)`, '', fmt(oh)]);
  rows.push(['',`Insurance (${p.pct_ins}%)`, '', fmt(ins)]);
  rows.push(['','GRAND TOTAL','', fmt(grand)]);

  const ws1 = XLSX.utils.aoa_to_sheet(rows);
  ws1['!cols'] = [{wch:8},{wch:52},{wch:22},{wch:16}];
  XLSX.utils.book_append_sheet(wb, ws1, 'Proposal');

  // ── BID FORM SHEET ──
  const bf = [];
  bf.push(['BID FORM']);
  bf.push(['DATE:', new Date().toLocaleDateString()]);
  bf.push(['PROJECT:', p.address]);
  bf.push(['ADDRESS:', 'SAME AS ABOVE']);
  bf.push(['ARCHITECT:', p.architect]);
  bf.push(['CONTRACTOR:', 'NI Construction Corp.']);
  bf.push(['PROJECT MANAGER:', p.pm]);
  bf.push([]);
  bf.push(['Division #','','','Remark','Division Cost']);

  p.divisions.forEach(div => {
    const dt = div.items.reduce((s,it)=>s+(parseFloat(it.cost)||0),0);
    bf.push([div.div, div.name,'','', dt||'']);
    div.items.forEach(it => bf.push(['', it.name,'', it.remark||'', it.cost||'']));
  });

  bf.push([]);
  bf.push(['','SUBTOTAL','','', sub]);
  bf.push(['','General Conditions','','', gc]);
  bf.push(['','Overhead','','', oh]);
  bf.push(['','Insurance','','', ins]);
  bf.push(['','GRAND TOTAL','','', grand]);

  const ws2 = XLSX.utils.aoa_to_sheet(bf);
  ws2['!cols'] = [{wch:8},{wch:50},{wch:4},{wch:22},{wch:16}];
  XLSX.utils.book_append_sheet(wb, ws2, 'Bid Form');

  const buf = XLSX.write(wb, { type:'buffer', bookType:'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="NI-Bid-${p.bid_number}.xlsx"`);
  res.send(buf);
});

// ── CATCH-ALL → serve app ─────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(CLIENT_DIR, 'index.html'));
});

// ── START ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════╗
║   NI Construction — AI Bid Generator         ║
║   Running at http://localhost:${PORT}           ║
╚══════════════════════════════════════════════╝
  `);
});

// ── AI PROMPT ─────────────────────────────────────────────────────────────────
const ANALYSIS_PROMPT = `You are an expert NYC construction estimator for NI Construction Corp (License #2056165-DCA).

Analyze these architectural drawings carefully. Extract ALL scope items and generate a detailed cost estimate using these CALIBRATED NYC PRE-WAR BUILDING RATES (from NI's actual completed proposal #2030a21, 52 Riverside Dr, $548K, Feb 2026):

RATE CARD:
- Site protection: $5,000–$12,000 LS depending on apt size
- Demo full gut: $28–$42/SF; selective demo: $18–$28/SF
- Metal stud framing: $8–$12/SF
- IKEA millwork receive+fab: $350–$500/LF total run
- Standard millwork: $1,050/LF base cabinets, $925/LF upper cabinets
- Baseboard/trim: $5–$8/LF installed
- Door frames (wood): $300–$450 EA
- Waterproofing (Laticrete 9235): $4–$8/SF
- Sound mat (Regupol): $2.50–$4/SF
- SAFB acoustic batt: $1.80–$2.50/SF
- Joint sealant + fire stopping: $1,500–$3,500 LS
- Solid core wood doors (pivot, MDF): $800–$1,400 EA incl. hardware
- Pocket/sliding doors: $900–$1,500 EA incl. Cavilock hardware
- GWB assemblies (frame+board+tape+finish): $10–$16/SF
- Level 5 skim coat: $4–$6/SF
- Ceramic/porcelain tile setting (labor only): $14–$28/SF (tile by owner unless noted)
- Stone saddle: $180–$280 EA
- Engineered wood floor install: $12–$18/SF installed
- Interior paint: $1.80–$2.50/SF
- Bath accessories install only: $300–$600/room
- Shower glass enclosure: $2,800–$5,500 supply+install
- Plumbing rough-in per fixture: $2,200–$3,800 EA
- Plumbing connect (fixtures by owner): $800–$1,400 EA
- Electrical full rewire: $22–$35/SF (fixtures by owner if noted)

NYC OCCUPIED BUILDING MULTIPLIERS (apply to all costs):
- Pre-war building: +15%
- 6th floor+: +8% elevator/logistics
- Occupied building: +12% tenant protection

RESPOND ONLY WITH THIS EXACT JSON FORMAT:

\`\`\`json
{
  "project_address": "address from drawings",
  "architect": "architect name from drawings",
  "scope_summary": "Detailed 3-paragraph scope description: what rooms, what demo, what's new, what's by owner, SF, bath count, kitchen type, door count, finish types, plumbing fixture count.",
  "line_items": [
    {
      "division": "02",
      "division_name": "EXISTING CONDITIONS",
      "name": "Site Protection — interior and public hallways",
      "remark": "",
      "quantity": 1,
      "unit": "LS",
      "cost": 6500
    }
  ]
}
\`\`\`

Include ALL CSI divisions: 02, 05, 06, 07, 08, 09, 10, 22, 26.
For "by owner" items per drawings, set cost to 0, remark "by owner".
Read actual dimensions from plans. Be precise.`;

# NI Construction Corp — AI Bid Generator
### Deploy Guide — Get running in ~10 minutes

---

## What You Get
- **Private web app** — your team logs in, nobody else can access it
- **Upload drawings → AI generates bid** — Claude reads PDFs/images and prices every line item
- **All bids saved** to a database on the server
- **Export** Excel (NI proposal + architect bid form), PDF, CSV
- **Multi-user** — add teammates in server/index.js

---

## STEP 1 — Get Your Anthropic API Key
1. Go to **https://console.anthropic.com**
2. Sign in (or create account)
3. Click **API Keys → Create Key**
4. Copy the key (starts with `sk-ant-...`) — you'll need it in Step 3

---

## STEP 2 — Deploy to Render (free, easiest)

### 2A — Push code to GitHub
```bash
# On your computer, install Git if needed: https://git-scm.com
cd ni-bid-app
git init
git add .
git commit -m "Initial deploy"

# Create a new repo at github.com (click + → New Repository → name it "ni-bid-app")
# Then run the two commands GitHub shows you, e.g.:
git remote add origin https://github.com/YOUR_USERNAME/ni-bid-app.git
git push -u origin main
```

### 2B — Deploy on Render
1. Go to **https://render.com** → Sign up (free)
2. Click **New → Web Service**
3. Connect your GitHub → select **ni-bid-app**
4. Fill in:
   - **Name:** `ni-bid-app`
   - **Runtime:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `node server/index.js`
   - **Instance Type:** Free (or Starter $7/mo for always-on)
5. Click **Advanced → Add Environment Variables** and add:

| Key | Value |
|-----|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-YOUR_KEY_HERE` |
| `SESSION_SECRET` | any 32+ character random string |
| `ADMIN_PASSWORD` | password for logging in |
| `NODE_ENV` | `production` |

6. Click **Create Web Service**
7. Wait ~3 minutes → Render gives you a URL like `https://ni-bid-app.onrender.com`

**That's it. Open the URL, log in as `naim` with your ADMIN_PASSWORD.**

---

## ALTERNATIVE — Run Locally (on your office computer)

```bash
# Install Node.js from https://nodejs.org (LTS version)

# In terminal / command prompt:
cd ni-bid-app
npm install

# Create your .env file:
cp .env.example .env
# Edit .env and fill in ANTHROPIC_API_KEY and ADMIN_PASSWORD

# Start the server:
npm start

# Open browser to: http://localhost:3000
```

To keep it running permanently on a Mac/PC, use PM2:
```bash
npm install -g pm2
pm2 start server/index.js --name ni-bid
pm2 startup    # makes it restart on reboot
pm2 save
```

---

## STEP 3 — Add More Team Members
Edit `server/index.js` around line 35:
```js
seedUser('naim',     process.env.ADMIN_PASSWORD, 'admin');
seedUser('estimator1', 'theirpassword123',       'estimator');
seedUser('pm1',        'anotherpassword',        'estimator');
```
Then redeploy (push to GitHub → Render auto-deploys).

---

## STEP 4 — Connect a Custom Domain (optional)
In Render → your service → **Custom Domains → Add Domain**
e.g. `bids.niconstruction.com`
Then add the CNAME record in your domain registrar (GoDaddy/Namecheap etc.)

---

## File Structure
```
ni-bid-app/
├── server/
│   └── index.js          ← Express server, API routes, AI proxy
├── client/
│   └── public/
│       └── index.html    ← Full frontend (login, upload, bid editor, exports)
├── data/
│   └── ni.db             ← SQLite database (auto-created on first run)
├── package.json
├── .env.example          ← Copy to .env and fill in
└── README.md
```

---

## Cost
| Service | Cost |
|---------|------|
| Render (free tier) | $0 (sleeps after 15min inactivity) |
| Render Starter | $7/month (always on, recommended) |
| Anthropic API | ~$0.50–$2.00 per bid generated (11-page drawing set) |

---

## Troubleshooting
- **"ANTHROPIC_API_KEY not configured"** → Check environment variables in Render dashboard
- **Login fails** → Check ADMIN_PASSWORD env var matches what you're typing
- **App sleeping (free tier)** → Upgrade to Render Starter ($7/mo) or use a free uptime monitor like UptimeRobot
- **File too large** → Max 20MB per file, 20 files per upload. Compress PDFs first.

---

## Support
Contact: Naim Ibrahimov · NI Construction Corp · Lic. #2056165-DCA
